import { useEffect, useState } from 'react'

const photos = {
  hero: 'https://images.unsplash.com/photo-1632835298280-ad3d64834ab8?auto=format&fit=crop&w=1800&q=85',
  hero2: 'https://images.unsplash.com/photo-1663507898277-e4f94adc9333?auto=format&fit=crop&w=1800&q=85',
  hero3: 'https://images.unsplash.com/photo-1531496730074-83b638c0a7ac?auto=format&fit=crop&w=1800&q=85',
  woman: 'https://images.unsplash.com/photo-1758873268180-d95d10c86588?auto=format&fit=crop&w=700&q=80',
  man: 'https://images.unsplash.com/photo-1549045337-967927d923c0?auto=format&fit=crop&w=700&q=80',
  man2: 'https://images.unsplash.com/photo-1601392561050-340745ba9c25?auto=format&fit=crop&w=700&q=80',
}

const Icon = ({ name, size = 18 }: { name: string; size?: number }) => {
  const paths: Record<string, React.ReactNode> = {
    phone: <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8 10a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c1 .3 1.9.6 2.9.7a2 2 0 0 1 1.7 2z"/>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 22a8 8 0 0 1 16 0"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    play: <path d="m9 7 8 5-8 5z"/>,
    award: <><circle cx="12" cy="8" r="6"/><path d="m8.5 13-1 9 4.5-3 4.5 3-1-9"/></>,
    arrow: <><path d="M5 12h14"/><path d="m14 7 5 5-5 5"/></>,
    up: <path d="m6 15 6-6 6 6"/>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    close: <><path d="m6 6 12 12M18 6 6 18"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    map: <><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2"/></>,
  }
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

const categories = ['Certificación', 'Desarrollo web', 'Data Science', 'IA generativa', 'Robótica', 'Seguridad ocupacional']
const courses = [
  { cat: 'Certificación', title: 'Formador de Formadores', hours: 40, image: photos.hero2 },
  { cat: 'Desarrollo web', title: 'Desarrollo Web con React', hours: 48, image: photos.hero3 },
  { cat: 'Data Science', title: 'Power BI para la toma de decisiones', hours: 32, image: photos.hero },
  { cat: 'IA generativa', title: 'Inteligencia Artificial para docentes', hours: 24, image: photos.woman },
  { cat: 'Robótica', title: 'Robótica educativa desde cero', hours: 36, image: photos.man },
  { cat: 'Seguridad ocupacional', title: 'Prevención de riesgos laborales', hours: 40, image: photos.man2 },
]

const Logo = () => <a href="#/" className="logo" aria-label="Educalab inicio"><span className="cap">⌃</span><strong>EDUCA</strong><b>LAB</b><small>.EC</small></a>

function Header({ navigate, enroll }: { navigate: (p: string) => void; enroll: () => void }) {
  const [open, setOpen] = useState(false)
  const go = (p: string) => { navigate(p); setOpen(false) }
  return <>
    <div className="topbar"><div className="wrap topinner"><span><Icon name="phone" size={14}/> +593 97 889 3727</span><span><Icon name="mail" size={14}/> cursos@educalab.ec</span><button onClick={() => go('login')}><Icon name="user" size={14}/> Iniciar sesión / Registrarse</button></div></div>
    <header>
      <div className="wrap nav"><Logo/>
        <nav className={open ? 'open' : ''}>
          <button onClick={() => go('inicio')}>INICIO</button>
          <button onClick={() => go('certificado')}>CERTIFÍCATE</button>
          <button onClick={() => { go('inicio'); setTimeout(() => document.querySelector('#cursos')?.scrollIntoView({behavior:'smooth'}), 10)}}>CURSOS</button>
          <button onClick={() => go('servicios')}>SERVICIOS</button>
          <button onClick={() => go('contacto')}>CONTACTO</button>
        </nav>
        <button className="btn nav-cta" onClick={enroll}>Inscribirme <Icon name="arrow" size={16}/></button>
        <button className="hamb" onClick={() => setOpen(!open)} aria-label="Abrir menú"><Icon name={open ? 'close' : 'menu'}/></button>
      </div>
    </header>
  </>
}

const Footer = ({ navigate }: { navigate: (p:string)=>void }) => <footer>
  <div className="wrap footer-grid">
    <div><Logo/><p>Educación práctica para impulsar tu futuro profesional desde Ecuador hacia el mundo.</p><div className="socials"><i>f</i><i>in</i><i>ig</i></div></div>
    <div><h4>CONTACTO</h4><p>Av. República, Quito, Ecuador</p><p>+593 97 889 3727</p><p>cursos@educalab.ec</p></div>
    <div><h4>EDUCALAB.EC</h4><button onClick={() => navigate('servicios')}>Servicios</button><button onClick={() => navigate('contacto')}>Contáctanos</button><button onClick={() => navigate('certificado')}>Verificar certificado</button></div>
    <div><h4>ESPECIALIZACIONES</h4><p>Desarrollo web</p><p>Data Science</p><p>Inteligencia Artificial</p><h4 className="second">CERTIFICACIONES</h4><p>Formación de formadores</p></div>
  </div><div className="copyright">© 2026 EDUCALAB.EC. Todos los derechos reservados.</div>
</footer>

function Home({ enroll, navigate }: { enroll:()=>void; navigate:(p:string)=>void }) {
  const [slide, setSlide] = useState(0)
  const [category, setCategory] = useState('Certificación')
  const slides = [
    {tag:'APRENDE. CRECE. TRANSFORMA.', title:'La educación que necesitas para avanzar', text:'Cursos prácticos y certificaciones que conectan tus habilidades con nuevas oportunidades.', image:photos.hero},
    {tag:'APRENDE DE LOS MEJORES', title:'Domina las habilidades del futuro', text:'Tecnología, innovación y metodología aplicada con instructores que sí trabajan en la industria.', image:photos.hero2},
    {tag:'ESTUDIA A TU RITMO', title:'Tu próxima meta empieza hoy', text:'Formación flexible, acompañamiento cercano y certificados que respaldan tu crecimiento.', image:photos.hero3},
  ]
  useEffect(() => { const id = setInterval(() => setSlide(s => (s + 1) % 3), 5500); return () => clearInterval(id)}, [])
  const current = slides[slide]
  const shown = courses.filter(c => c.cat === category)
  return <>
    <section className="hero" style={{backgroundImage:`linear-gradient(90deg,rgba(20,20,20,.92),rgba(20,20,20,.2)),url(${current.image})`}}>
      <div className="wrap hero-content"><div className="eyebrow">{current.tag}</div><h1>{current.title}</h1><p>{current.text}</p><button className="btn" onClick={enroll}>¿Listo para empezar? <Icon name="arrow"/></button></div>
      <div className="dots">{slides.map((_,i)=><button key={i} className={i===slide?'active':''} onClick={()=>setSlide(i)} aria-label={`Diapositiva ${i+1}`}/>)}</div>
    </section>
    <section className="trust"><div className="wrap trust-grid"><div><strong>+1.500</strong><span>estudiantes capacitados</span></div><div><strong>+35</strong><span>cursos especializados</span></div><div><strong>4.9/5</strong><span>valoración promedio</span></div><div><strong>100%</strong><span>aprendizaje práctico</span></div></div></section>
    <section className="section" id="cursos"><div className="wrap">
      <div className="section-head"><div><span className="overline">APRENDE ALGO NUEVO</span><h2>Cursos que impulsan <em>tu carrera</em></h2></div><p>Programas creados para el mercado actual, con contenido práctico y acompañamiento experto.</p></div>
      <div className="tabs">{categories.map(c=><button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div>
      <div className="course-grid">{shown.map(c=><article className="course" key={c.title}>
        <div className="course-img"><img src={c.image} alt={c.title}/><span className="tag">NUEVO</span></div>
        <div className="course-body"><span className="course-cat">{c.cat}</span><div className="price">$80<small> USD</small></div><h3>{c.title}</h3><div className="meta"><span><Icon name="clock" size={16}/>{c.hours} horas</span><span><Icon name="play" size={16}/>En línea</span></div><button onClick={enroll}>Inscribirme <Icon name="arrow" size={16}/></button></div>
      </article>)}</div>
      <div className="center"><button className="outline" onClick={()=>navigate('servicios')}>Ver todos los programas <Icon name="arrow" size={16}/></button></div>
    </div></section>
    <section className="right-place"><div className="wrap split"><div><span className="overline light">POR QUÉ EDUCAlab</span><h2>Aterrizaste en el lugar adecuado</h2><p>Aprender no debería sentirse lejano ni complicado. Diseñamos experiencias claras, útiles y humanas para que cada hora invertida se convierta en una habilidad real.</p><ul><li><Icon name="check"/>Contenido actualizado y aplicable</li><li><Icon name="check"/>Instructores con experiencia real</li><li><Icon name="check"/>Certificación verificable</li></ul><button className="btn" onClick={enroll}>Quiero empezar</button></div><div className="video-card"><img src={photos.hero2} alt="Clase práctica en Educalab"/><button aria-label="Reproducir video"><Icon name="play" size={26}/></button><div><strong>Aprende haciendo</strong><span>Una metodología enfocada en resultados.</span></div></div></div></section>
    <section className="instructors"><div className="wrap"><span className="overline light">CONOCE A NUESTRO EQUIPO</span><h2>Aprende con quienes <em>sí lo hacen</em></h2><div className="people">
      {[['Carla Mendoza','Especialista en IA',photos.woman,'8 cursos'],['Diego Salazar','Desarrollador full stack',photos.man,'6 cursos'],['Mateo Ruiz','Analista de datos',photos.man2,'5 cursos']].map(p=><article key={p[0]}><img src={p[2]} alt={p[0]}/><div><h3>{p[0]}</h3><p>{p[1]}</p><span>{p[3]} · Habla español e inglés</span></div></article>)}
    </div></div></section>
    <section className="section testimonials"><div className="wrap"><div className="section-head"><div><span className="overline">HISTORIAS REALES</span><h2>Lo que dicen nuestros <em>estudiantes</em></h2></div></div><div className="test-grid">
      {[['Rafaela Silva','“El curso fue directo, claro y aplicable. Me gustó poder avanzar a mi ritmo sin sentirme sola.”',photos.woman],['Joyce Rodríguez','“Logré organizar mejor mis proyectos y presentar resultados desde la primera semana.”','https://images.unsplash.com/photo-1731419223715-aec6664f9011?auto=format&fit=crop&w=300&q=80'],['David Cobos','“Los instructores explican desde la experiencia. Recomiendo Educalab por su enfoque práctico.”',photos.man]].map(t=><article key={t[0]}><div className="stars">★★★★★</div><p>{t[1]}</p><div className="author"><img src={t[2]} alt={t[0]}/><div><strong>{t[0]}</strong><span>Estudiante verificado</span></div></div></article>)}
    </div></div></section>
    <section className="cta"><div className="wrap"><span>TU SIGUIENTE PASO EMPIEZA AQUÍ</span><h2>Aprende hoy. Destaca mañana.</h2><p>Únete a una comunidad que ya está transformando su futuro.</p><button className="dark-btn" onClick={enroll}>Inscribirme ahora <Icon name="arrow"/></button></div></section>
  </>
}

const PageBanner = ({title, crumb}:{title:string;crumb?:string}) => <section className="page-banner"><div className="wrap"><span>INICIO / {crumb || title}</span><h1>{title}</h1></div></section>

function Services({enroll}:{enroll:()=>void}) {
  const list = [
    ['Capacitación corporativa','Programas a la medida para fortalecer las competencias de tu equipo y alcanzar objetivos medibles.'],
    ['Diseño instruccional','Convertimos conocimiento experto en experiencias de aprendizaje claras, atractivas y efectivas.'],
    ['Aulas virtuales','Implementación y acompañamiento de plataformas para organizar, impartir y medir tu formación.'],
  ]
  return <><PageBanner title="SERVICIOS"/><section className="section"><div className="wrap"><div className="section-head"><div><span className="overline">SOLUCIONES PARA CRECER</span><h2>Aprendizaje que se adapta <em>a tu organización</em></h2></div><p>Te acompañamos desde el diagnóstico hasta la implementación con soluciones pensadas para tu realidad.</p></div><div className="service-grid">{list.map((s,i)=><article key={s[0]}><span>0{i+1}</span><Icon name={i===0?'user':i===1?'award':'play'} size={32}/><h3>{s[0]}</h3><p>{s[1]}</p><button onClick={enroll}>Solicitar información <Icon name="arrow" size={16}/></button></article>)}</div></div></section><section className="cta"><div className="wrap"><h2>Construyamos tu plan de formación</h2><p>Cuéntanos tu reto y diseñaremos una propuesta para tu equipo.</p><button className="dark-btn" onClick={enroll}>Hablar con un asesor</button></div></section></>
}

function Contact() {
  const [sent,setSent]=useState(false)
  return <><PageBanner title="CONTACTO"/><section className="section"><div className="wrap contact-grid"><div><span className="overline">ESTAMOS PARA AYUDARTE</span><h2>Conversemos sobre <em>tu próxima meta</em></h2><p>Escríbenos y uno de nuestros asesores se pondrá en contacto contigo.</p><div className="contact-line"><Icon name="phone"/><div><small>TELÉFONO</small><strong>+593 97 889 3727</strong></div></div><div className="contact-line"><Icon name="mail"/><div><small>CORREO</small><strong>cursos@educalab.ec</strong></div></div><div className="contact-line"><Icon name="map"/><div><small>UBICACIÓN</small><strong>Quito, Ecuador</strong></div></div></div><form onSubmit={e=>{e.preventDefault();setSent(true)}}><label>Nombre completo<input required placeholder="Escribe tu nombre"/></label><label>Correo electrónico<input required type="email" placeholder="nombre@correo.com"/></label><label>Teléfono<input required placeholder="+593"/></label><label>¿En qué podemos ayudarte?<select><option>Información sobre cursos</option><option>Capacitación corporativa</option><option>Soporte</option></select></label><label>Mensaje<textarea rows={4} placeholder="Cuéntanos un poco más..."/></label><button className="btn">{sent?'Mensaje enviado':'Enviar mensaje'} <Icon name="arrow"/></button>{sent&&<p className="success">Gracias. Pronto nos pondremos en contacto.</p>}</form></div></section></>
}

function Certificate() {
  const [code,setCode]=useState(''); const [result,setResult]=useState<'ok'|'bad'|null>(null)
  return <><PageBanner title="VERIFICA TU CERTIFICADO" crumb="CERTIFICACIONES"/><section className="section certificate-section"><div className="wrap cert-grid"><div><span className="overline">RESPALDO DIGITAL</span><h2>Un logro que puedes <em>comprobar</em></h2><p>Ingresa el código que aparece en tu certificado para validar su autenticidad.</p><div className="verify"><input value={code} onChange={e=>setCode(e.target.value.toUpperCase())} placeholder="Ej. EDL-2026-0481"/><button className="btn" onClick={()=>setResult(code.trim()==='EDL-2026-0481'?'ok':'bad')}>Verificar</button></div>{result&&<div className={result==='ok'?'valid':'invalid'}><Icon name={result==='ok'?'check':'close'}/>{result==='ok'?'Certificado válido · Rafaela Silva · Formador de Formadores':'No encontramos un certificado con este código.'}</div>}</div><div className="certificate"><div className="cert-top"><Logo/><span>EDL-2026-0481</span></div><p>CERTIFICADO DE APROBACIÓN</p><h3>Rafaela Silva</h3><span>ha aprobado satisfactoriamente el programa</span><h4>FORMADOR DE FORMADORES</h4><div className="cert-bottom"><div><b>María Fernanda León</b><small>Dirección académica</small></div><div className="qr">{Array.from({length:64}).map((_,i)=><i key={i} className={(i*7+i%5)%3===0?'on':''}/>)}</div></div></div></div></section></>
}

function Login() {
  return <><PageBanner title="INICIAR SESIÓN"/><section className="login-section"><form onSubmit={e=>e.preventDefault()}><Logo/><h2>Qué gusto verte de nuevo</h2><p>Ingresa a tu aula virtual.</p><label>Correo electrónico<input type="email" placeholder="nombre@correo.com"/></label><label>Contraseña<input type="password" placeholder="••••••••"/></label><div className="login-row"><label><input type="checkbox"/> Recordarme</label><button>Olvidé mi contraseña</button></div><button className="btn wide">Iniciar sesión</button><p>¿Aún no tienes cuenta? <b>Regístrate</b></p></form></section></>
}

function Enrollment({close}:{close:()=>void}) {
  const [step,setStep]=useState(1), [coupon,setCoupon]=useState(''), [discount,setDiscount]=useState(false)
  return <div className="modal-bg" onMouseDown={e=>{if(e.target===e.currentTarget)close()}}><div className="modal"><button className="modal-close" onClick={close}><Icon name="close"/></button><div className="steps">{[1,2,3].map((n)=><div className={step>=n?'active':''} key={n}><i>{step>n?'✓':n}</i><span>{n===1?'Datos':n===2?'Pago':'Confirmación'}</span></div>)}</div>
    {step===1&&<div className="step-content"><span className="overline">PASO 1 DE 3</span><h2>Cuéntanos sobre ti</h2><div className="two"><label>Nombres<input placeholder="Tus nombres"/></label><label>Apellidos<input placeholder="Tus apellidos"/></label></div><label>Correo electrónico<input type="email" placeholder="nombre@correo.com"/></label><label>Teléfono<input placeholder="+593"/></label><button className="btn wide" onClick={()=>setStep(2)}>Continuar al pago <Icon name="arrow"/></button></div>}
    {step===2&&<div className="step-content"><span className="overline">PASO 2 DE 3</span><h2>Resumen y pago</h2><div className="order"><span>Formador de Formadores</span><b>$80,00</b>{discount&&<><span>Descuento PRIMERA10</span><b>−$8,00</b></>}<strong>Total</strong><strong>${discount?'72,00':'80,00'}</strong></div><label>Cupón<div className="coupon"><input value={coupon} onChange={e=>setCoupon(e.target.value.toUpperCase())} placeholder="Código de descuento"/><button onClick={()=>setDiscount(coupon==='PRIMERA10')}>Aplicar</button></div></label>{coupon&&coupon!=='PRIMERA10'&&<small className="error">Ingresa PRIMERA10 para obtener 10% de descuento.</small>}<label>Número de tarjeta<input placeholder="0000 0000 0000 0000"/></label><div className="two"><label>Vencimiento<input placeholder="MM/AA"/></label><label>CVV<input placeholder="123"/></label></div><button className="btn wide" onClick={()=>setStep(3)}>Pagar e inscribirme</button></div>}
    {step===3&&<div className="step-content done"><i><Icon name="check" size={38}/></i><span className="overline">INSCRIPCIÓN CONFIRMADA</span><h2>¡Bienvenido a Educalab!</h2><p>Tu cupo está reservado. Enviamos los detalles de acceso a tu correo electrónico.</p><button className="btn" onClick={close}>Volver al inicio</button></div>}
  </div></div>
}

export default function App() {
  const routeFromHash = () => (location.hash.replace('#/','') || 'inicio')
  const [route,setRoute]=useState(routeFromHash), [enroll,setEnroll]=useState(false)
  useEffect(()=>{const fn=()=>{setRoute(routeFromHash());window.scrollTo(0,0)};addEventListener('hashchange',fn);return()=>removeEventListener('hashchange',fn)},[])
  const navigate=(p:string)=>{location.hash=`/${p}`}
  return <><Header navigate={navigate} enroll={()=>setEnroll(true)}/><main>{route==='inicio'?<Home enroll={()=>setEnroll(true)} navigate={navigate}/>:route==='servicios'?<Services enroll={()=>setEnroll(true)}/>:route==='contacto'?<Contact/>:route==='certificado'?<Certificate/>:<Login/>}</main><Footer navigate={navigate}/>
    <div className="floating"><a href="https://wa.me/593978893727" target="_blank" rel="noreferrer" className="whatsapp" aria-label="WhatsApp">W</a><button onClick={()=>scrollTo({top:0,behavior:'smooth'})} aria-label="Volver arriba"><Icon name="up"/></button></div>
    <div className="mobile-bar"><button onClick={()=>setEnroll(true)}>Inscribirme</button><a href="https://wa.me/593978893727">WhatsApp</a></div>
    {enroll&&<Enrollment close={()=>setEnroll(false)}/>}</>
}
